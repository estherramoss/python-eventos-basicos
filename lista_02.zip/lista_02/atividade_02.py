print("===Altura em CM===")

# alturas
altura1 = input("Informe a altura da 1° pessoa: ")
altura2 = input("Informe a altura 2° pessoa: ")

# Sistema de comparação
if altura1 > altura2:
    print("A 1° pessoa é mais alta")
else:
    print("A 2° pessoa é mais alta")