# Var
nota = int(input("Informe a nota: "))

# uso if ternario
alerta = "Deu uma de ESTER!" if nota<5 else "APROVADO!"

# Alerta
print(alerta)